﻿function formatCurrency(value) { return "$" + value.toFixed(2); }



var cartLine = function () {
    this.category = ko.observable();
    this.product = ko.observable();
    this.quantity = ko.observable(1);
    this.subtotal = ko.dependentObservable(function () {
        return this.product() ? this.product().price * parseInt("0" + this.quantity(), 10) : 0;
    }.bind(this));

    // Whenever the category changes, reset the product selection
    this.category.subscribe(function () { this.product(undefined); }.bind(this));
};
var cart = function () {
    // Stores an array of lines, and from these, can work out the grandTotal
    this.lines = ko.observableArray([new cartLine()]);   // Put one line in by default

    this.grandTotal = ko.dependentObservable(function () {
        var total = 0;
        for (var i = 0; i < this.lines().length; i++)
            total += this.lines()[i].subtotal();
        return total;
    }.bind(this));

    // Operations
    this.addLine = function () { this.lines.push(new cartLine()) };
    this.removeLine = function (line) { this.lines.remove(line) };
    this.save = function () {
        var dataToSave = $.map(this.lines(), function (line) {
            return line.product() ? { productName: line.product().name, quantity: line.quantity() } : undefined
        });

        alert("Could now send this to server: " + JSON.stringify(dataToSave));
        
    };

    // Debug
    this.getDebugText = function () {
        return JSON.stringify(ko.toJS(this.lines()), null, 2);
    }
};

var cartViewModel = new cart();


$(function () {
    ko.applyBindings(cartViewModel);
});



// Some of the Knockout examples use this data
var sampleProductCategories = [
  {
      "products": [
        {
            "name": "milk",
            "price": 3.9
        },
        {
            "name": "eggs",
            "price": 2.16
        },
        {
            "name": "cheese",
            "price": 2.25
        },
        {
            "name": "yogurt",
            "price": 2.58
        }
      ],
      "name": "Dairy"
  },
    {
        "products": [
          {
              "name": "breakfastbars",
              "price": 3.9
          },
          {
              "name": "cereals",
              "price": 2.16
          },
          {
              "name": "toasterpastriess",
              "price": 2.25
          },
          {
              "name": "waffles",
              "price": 2.58
          }
        ],
        "name": "breakfastandcereal"
    },
    {
        "products": [
          {
              "name": "coke",
              "price": 3.9
          },
          {
              "name": "juice",
              "price": 2.16
          },
          {
              "name": "tea",
              "price": 2.25
          },
          {
              "name": "water",
              "price": 2.58
          }
        ],
        "name": "beverages"
    },
    {
        "products": [
          {
              "name": "cookies",
              "price": 3.9
          },
          {
              "name": "chips",
              "price": 2.16
          },
          {
              "name": "candy",
              "price": 2.25
          },
          {
              "name": "nuts",
              "price": 2.58
          }
        ],
        "name": "snacks"
    }





];