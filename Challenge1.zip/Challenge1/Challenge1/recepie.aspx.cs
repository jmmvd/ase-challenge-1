﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace Challenge1
{
    public partial class recepie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void recepiebtn_Click(object sender, EventArgs e)
        {
            recepiesresult.Text = "";
            String data = recp.Text.ToString();
            String StoreRequest = CreateRequest(data);
            XmlDocument StoreResponse = MakeRequest(StoreRequest);

            ProcessResponse(StoreResponse);



        }
        public string CreateRequest(string queryString)
        {
            string UrlRequest = "http://www.supermarketapi.com/api.asmx/SearchByItemID?APIKEY=0295cbc332&ItemId=" + queryString;
            return (UrlRequest);


        }
        public XmlDocument MakeRequest(string requestUrl)
        {
            try
            {
                HttpWebRequest request = WebRequest.Create(requestUrl) as HttpWebRequest;
                HttpWebResponse response = request.GetResponse() as HttpWebResponse;

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(response.GetResponseStream());
                return (xmlDoc);

            }
            catch (Exception e)
            {
                recepiesresult.Text = e.Message;
                return null;
            }
        }
        public void ProcessResponse(XmlDocument locationsResponse)
        {
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(locationsResponse.NameTable);
            nsmgr.AddNamespace("product", "http://www.SupermarketAPI.com");
            //Get formatted addresses: Option 1
            //Get all locations in the response and then extract the formatted address for each location
            XmlNodeList locationElements = locationsResponse.SelectNodes("//product:Product_Commercial", nsmgr);

            foreach (XmlNode Itemname in locationElements)
            {
                for (int i = 0; i < Itemname.ChildNodes.Count; i++)
                {
                    if (i == 4)
                    {
                        recepiesresult.Text = recepiesresult.Text + "<img src='" + Itemname.ChildNodes[i].InnerText + "'/><br/>";
                    }
                    else
                    {
                        recepiesresult.Text = recepiesresult.Text + i + ")" + Itemname.ChildNodes[i].Name + ": " + Itemname.ChildNodes[i].InnerText + "<br/>";
                    }
                }
                recepiesresult.Text = recepiesresult.Text + "<hr/>";

            }
        }
    }
}